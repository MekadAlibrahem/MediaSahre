<?php
$path = "http://localhost/mediashare/resources/" ;
echo '
    <link rel="stylesheet" href="'. $path.'bootstrap-5.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="'.$path.'fontawesome6.0.0/css/all.min.css">
    <link rel="stylesheet" href="'.$path.'css/style.css">
    
    

        '  ;


?>