<?php 

echo '
<nav class="main-nav navbar navbar-expand-lg navbar-light  m-0 p-0 sticky-top">
        <div class="container">
          <a class="navbar-brand " href="../index.php"> 
            <img src="../../resources/images/logo3.png" width="50" height="40" alt="">
            dataCloude
          </a>
            
        </div>
    </nav>





';

?>