<?php 
$path = "http://localhost/mediashare/resources/" ;
echo '
<script src="'.$path.'bootstrap-5.1.3/js/bootstrap.min.js"></script>
<script src="'.$path.'fontawesome6.0.0/js/all.min.js"></script>
<script src="'.$path.'js/jquery3.6.js"></script>
<script src ="'.$path.'js/jquery.validate.js"></script>





' ;

?>