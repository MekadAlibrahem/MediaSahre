<?php
namespace MediaShare ;
use FFI\Exception ;
use throwable ;
class Exceptions extends Exception implements throwable{

    

}


?>