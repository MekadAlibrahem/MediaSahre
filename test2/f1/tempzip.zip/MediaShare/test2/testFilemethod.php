<?php 

    // $info = new SplFileInfo('mekad/test/test.txt');
    // print($info->getPath());
    // $path    = './';
    // $used  = false ;
    // $files = scandir($path);
    // $files = array_diff(scandir($path), array('.', '..'));
    // foreach($files as $file){
    //     if($file == "test.tpxt")  $used  = true ;
    // }
    // echo $used ;
    require "../php/class.File.php" ;
    use MediaShare\File ;
use MediaShare\TypeFile;

    // try {
    //     $file = File::CreatObject(-1, "testfolder3" , 8 , 39 , 2);
    //     echo "<pre>" ;
    //     print_r($file); 
    //     echo "</pre>" ;
    // } catch (Exception $th) {
    //     print($th->getMessage());
    // }
    // if(isset($file)){
    //     try {
    //         $isCreate = File::create($file , true );
    //         echo "<pre>" ;
    //         print_r($isCreate); 
    //         echo "</pre>" ;
    //     } catch (Exception $th) {
    //         print($th->getMessage());
    //     }
    // }
   

    // try {
    //     $files = File::getListFileByParent(16);
    //         echo "<pre>" ;
    //         print_r($files); 
    //         echo "</pre>" ;
    // }catch (Exception $th) {
    //     print($th->getMessage());
    // }
    
    // $file = $files[1];
    
    // if(isset($file)){
    //     try {
    //            $isEdit = $file->editName("folder");
    //            if($isEdit ===true){
    //                echo "done" ;
    //            }
    //     } catch (Exception $th) {
    //         print($th->getMessage());
    //     }
    // }


    
 
   
?>