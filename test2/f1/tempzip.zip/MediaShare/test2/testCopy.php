<?php
require "../php/class.File.php";
use MediaShare\File ;
// Create a directory and file tree

mkdir('testcopy');
mkdir('testcopy/one-a');
touch('testcopy/one-a/testfile');
mkdir('testcopy/one-b');

// Add some hidden files for good measure

touch('testcopy/one-b/.hiddenfile');
mkdir('testcopy/one-c');
touch('testcopy/one-c/.hiddenfile');

// Add some more depth

mkdir('testcopy/one-c/two-a');
touch('testcopy/one-c/two-a/testfile');
mkdir('testcopy/one-d/');

// Test that symlinks are created properly

mkdir('testlink');
touch('testlink/testfile');


$status = File::xcopy('testcopy', 'testcopy-copy');

if (file_exists('testcopy-copy')
        && file_exists('testcopy-copy/one-b/.hiddenfile')
        && file_exists('testcopy-copy/one-c/two-a/testfile')
        
        && (readlink('testcopy-copy/one-d/my-symlink-relative') == '../') ){
    echo "TEST PASSED";
} else {
    echo "TEST FAILED";
}
?>