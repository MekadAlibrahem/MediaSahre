<?php
// $files = array('./pdo.php');
// $path_zip_file = './f1/tempzip/';
// $zipname = 'test2.zip';
// $zip = new ZipArchive;
// $zip->open($path_zip_file.$zipname, ZipArchive::CREATE);
// foreach ($files as $file) {
//   $zip->addFile($file);
// }
// $zip->close();

// ///Then download the zipped file.
// header('Content-Type: application/zip');
// header('Content-disposition: attachment; filename='.$zipname);
// header('Content-Length: ' . filesize($zipname));
// readfile($zipname);

// $zip = new ZipArchive;
// if ($zip->open("f1/tempzip/test.zip") === true) {
//     $zip->extractTo('f2/');
//     $zip->close();
// }
?>