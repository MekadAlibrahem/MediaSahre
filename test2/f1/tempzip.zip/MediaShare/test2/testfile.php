<?php 
include_once "../php/class.File.php" ;
use MediaShare\Files\File ;
use MediaShare\ManagerDataBase;
    


   
   $size = File::getRootFileSizeForUser(14);
//    if(empty($size)){ echo "0" ; return ; }
   echo $size ;
    

  
?>